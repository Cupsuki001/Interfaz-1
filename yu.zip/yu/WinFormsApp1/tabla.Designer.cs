﻿namespace WinFormsApp1
{
    partial class tabla
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            TXBadi = new Button();
            BTNborrar = new Button();
            TXBnomb = new TextBox();
            dataGridView1 = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            LBLconta = new Label();
            label4 = new Label();
            label5 = new Label();
            TXBsub = new TextBox();
            label6 = new Label();
            label7 = new Label();
            TXBsubfact = new TextBox();
            TXBfact = new TextBox();
            MSKcodigo = new MaskedTextBox();
            MSKprecio = new MaskedTextBox();
            MSKcant = new MaskedTextBox();
            label8 = new Label();
            TXBimpuesto = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(53, 57);
            label1.Name = "label1";
            label1.Size = new Size(58, 20);
            label1.TabIndex = 0;
            label1.Text = "Codigo";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(53, 146);
            label2.Name = "label2";
            label2.Size = new Size(64, 20);
            label2.TabIndex = 1;
            label2.Text = "Nombre";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(53, 221);
            label3.Name = "label3";
            label3.Size = new Size(50, 20);
            label3.TabIndex = 2;
            label3.Text = "Precio";
            // 
            // TXBadi
            // 
            TXBadi.Location = new Point(333, 214);
            TXBadi.Margin = new Padding(3, 4, 3, 4);
            TXBadi.Name = "TXBadi";
            TXBadi.Size = new Size(86, 31);
            TXBadi.TabIndex = 3;
            TXBadi.Text = "Adicionar";
            TXBadi.UseVisualStyleBackColor = true;
            TXBadi.Click += TXBadi_Click;
            // 
            // BTNborrar
            // 
            BTNborrar.Location = new Point(454, 215);
            BTNborrar.Margin = new Padding(3, 4, 3, 4);
            BTNborrar.Name = "BTNborrar";
            BTNborrar.Size = new Size(86, 31);
            BTNborrar.TabIndex = 4;
            BTNborrar.Text = "Borrar";
            BTNborrar.UseVisualStyleBackColor = true;
            BTNborrar.Click += BTNborrar_Click;
            // 
            // TXBnomb
            // 
            TXBnomb.Location = new Point(154, 135);
            TXBnomb.Margin = new Padding(3, 4, 3, 4);
            TXBnomb.Name = "TXBnomb";
            TXBnomb.Size = new Size(125, 27);
            TXBnomb.TabIndex = 6;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column5, Column4 });
            dataGridView1.Location = new Point(30, 276);
            dataGridView1.Margin = new Padding(3, 4, 3, 4);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(639, 200);
            dataGridView1.TabIndex = 8;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // Column1
            // 
            Column1.HeaderText = "Cdigo producto";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            Column1.Width = 125;
            // 
            // Column2
            // 
            Column2.HeaderText = "Nombre producto";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            Column2.Width = 125;
            // 
            // Column3
            // 
            Column3.HeaderText = "Precio producto";
            Column3.MinimumWidth = 6;
            Column3.Name = "Column3";
            Column3.Width = 125;
            // 
            // Column5
            // 
            Column5.HeaderText = "Cantidad";
            Column5.MinimumWidth = 6;
            Column5.Name = "Column5";
            Column5.Width = 125;
            // 
            // Column4
            // 
            Column4.HeaderText = "Subtotal producto";
            Column4.MinimumWidth = 6;
            Column4.Name = "Column4";
            Column4.Width = 125;
            // 
            // LBLconta
            // 
            LBLconta.AutoSize = true;
            LBLconta.Location = new Point(592, 214);
            LBLconta.Name = "LBLconta";
            LBLconta.Size = new Size(0, 20);
            LBLconta.TabIndex = 9;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(333, 46);
            label4.Name = "label4";
            label4.Size = new Size(69, 20);
            label4.TabIndex = 10;
            label4.Text = "Cantidad";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(306, 129);
            label5.Name = "label5";
            label5.Size = new Size(125, 20);
            label5.TabIndex = 11;
            label5.Text = "Sub total product";
            // 
            // TXBsub
            // 
            TXBsub.Location = new Point(454, 129);
            TXBsub.Margin = new Padding(3, 4, 3, 4);
            TXBsub.Name = "TXBsub";
            TXBsub.Size = new Size(114, 27);
            TXBsub.TabIndex = 13;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(106, 523);
            label6.Name = "label6";
            label6.Size = new Size(119, 20);
            label6.TabIndex = 14;
            label6.Text = "Sub total factura";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(484, 526);
            label7.Name = "label7";
            label7.Size = new Size(92, 20);
            label7.TabIndex = 15;
            label7.Text = "Total factura";
            // 
            // TXBsubfact
            // 
            TXBsubfact.Location = new Point(106, 561);
            TXBsubfact.Margin = new Padding(3, 4, 3, 4);
            TXBsubfact.Name = "TXBsubfact";
            TXBsubfact.Size = new Size(114, 27);
            TXBsubfact.TabIndex = 16;
            // 
            // TXBfact
            // 
            TXBfact.Location = new Point(478, 561);
            TXBfact.Margin = new Padding(3, 4, 3, 4);
            TXBfact.Name = "TXBfact";
            TXBfact.Size = new Size(114, 27);
            TXBfact.TabIndex = 17;
            // 
            // MSKcodigo
            // 
            MSKcodigo.Location = new Point(154, 57);
            MSKcodigo.Mask = "99999";
            MSKcodigo.Name = "MSKcodigo";
            MSKcodigo.Size = new Size(125, 27);
            MSKcodigo.TabIndex = 18;
            MSKcodigo.ValidatingType = typeof(int);
            // 
            // MSKprecio
            // 
            MSKprecio.Location = new Point(154, 219);
            MSKprecio.Mask = "99999";
            MSKprecio.Name = "MSKprecio";
            MSKprecio.Size = new Size(125, 27);
            MSKprecio.TabIndex = 19;
            MSKprecio.ValidatingType = typeof(int);
            // 
            // MSKcant
            // 
            MSKcant.Location = new Point(454, 54);
            MSKcant.Mask = "99999";
            MSKcant.Name = "MSKcant";
            MSKcant.Size = new Size(125, 27);
            MSKcant.TabIndex = 20;
            MSKcant.ValidatingType = typeof(int);
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(322, 523);
            label8.Name = "label8";
            label8.Size = new Size(71, 20);
            label8.TabIndex = 21;
            label8.Text = "Impuesto";
            // 
            // TXBimpuesto
            // 
            TXBimpuesto.Location = new Point(294, 561);
            TXBimpuesto.Name = "TXBimpuesto";
            TXBimpuesto.Size = new Size(125, 27);
            TXBimpuesto.TabIndex = 22;
            // 
            // tabla
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(681, 623);
            Controls.Add(TXBimpuesto);
            Controls.Add(label8);
            Controls.Add(MSKcant);
            Controls.Add(MSKprecio);
            Controls.Add(MSKcodigo);
            Controls.Add(TXBfact);
            Controls.Add(TXBsubfact);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(TXBsub);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(LBLconta);
            Controls.Add(dataGridView1);
            Controls.Add(TXBnomb);
            Controls.Add(BTNborrar);
            Controls.Add(TXBadi);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "tabla";
            Text = "tabla";
            Load += tabla_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Button TXBadi;
        private Button BTNborrar;
        private TextBox TXBnomb;
        private DataGridView dataGridView1;
        private Label LBLconta;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column4;
        private Label label4;
        private Label label5;
        private TextBox TXBsub;
        private Label label6;
        private Label label7;
        private TextBox TXBsubfact;
        private TextBox TXBfact;
        private MaskedTextBox MSKcodigo;
        private MaskedTextBox MSKprecio;
        private MaskedTextBox MSKcant;
        private Label label8;
        private TextBox TXBimpuesto;
    }
}