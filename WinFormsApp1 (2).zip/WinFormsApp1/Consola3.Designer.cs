﻿namespace WinFormsApp1
{
    partial class Consola3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MSKegre = new System.Windows.Forms.MaskedTextBox();
            this.MSKingr = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TXBresul = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.BTNcal = new System.Windows.Forms.Button();
            this.BTNlimp = new System.Windows.Forms.Button();
            this.BTNsalir = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // MSKegre
            // 
            this.MSKegre.Location = new System.Drawing.Point(39, 150);
            this.MSKegre.Mask = "999999";
            this.MSKegre.Name = "MSKegre";
            this.MSKegre.Size = new System.Drawing.Size(100, 23);
            this.MSKegre.TabIndex = 0;
            this.MSKegre.ValidatingType = typeof(int);
            // 
            // MSKingr
            // 
            this.MSKingr.Location = new System.Drawing.Point(39, 68);
            this.MSKingr.Mask = "999999";
            this.MSKingr.Name = "MSKingr";
            this.MSKingr.Size = new System.Drawing.Size(100, 23);
            this.MSKingr.TabIndex = 1;
            this.MSKingr.ValidatingType = typeof(int);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "Ingresos";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Egresos";
            // 
            // TXBresul
            // 
            this.TXBresul.Location = new System.Drawing.Point(278, 64);
            this.TXBresul.Name = "TXBresul";
            this.TXBresul.Size = new System.Drawing.Size(100, 23);
            this.TXBresul.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(297, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "Utilidad";
            // 
            // BTNcal
            // 
            this.BTNcal.Location = new System.Drawing.Point(229, 125);
            this.BTNcal.Name = "BTNcal";
            this.BTNcal.Size = new System.Drawing.Size(75, 23);
            this.BTNcal.TabIndex = 6;
            this.BTNcal.Text = "Calcular";
            this.BTNcal.UseVisualStyleBackColor = true;
            this.BTNcal.Click += new System.EventHandler(this.BTNcal_Click);
            // 
            // BTNlimp
            // 
            this.BTNlimp.Location = new System.Drawing.Point(357, 122);
            this.BTNlimp.Name = "BTNlimp";
            this.BTNlimp.Size = new System.Drawing.Size(75, 23);
            this.BTNlimp.TabIndex = 7;
            this.BTNlimp.Text = "Limpiar";
            this.BTNlimp.UseVisualStyleBackColor = true;
            this.BTNlimp.Click += new System.EventHandler(this.BTNlimp_Click);
            // 
            // BTNsalir
            // 
            this.BTNsalir.Location = new System.Drawing.Point(283, 182);
            this.BTNsalir.Name = "BTNsalir";
            this.BTNsalir.Size = new System.Drawing.Size(75, 23);
            this.BTNsalir.TabIndex = 8;
            this.BTNsalir.Text = "Salir";
            this.BTNsalir.UseVisualStyleBackColor = true;
            this.BTNsalir.Click += new System.EventHandler(this.BTNsalir_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.groupBox1.Controls.Add(this.MSKingr);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.MSKegre);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 206);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ingrese";
            // 
            // Consola3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(453, 237);
            this.Controls.Add(this.TXBresul);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.BTNsalir);
            this.Controls.Add(this.BTNlimp);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.BTNcal);
            this.Name = "Consola3";
            this.Text = "Consola3";
            this.Load += new System.EventHandler(this.Consola3_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaskedTextBox MSKegre;
        private MaskedTextBox MSKingr;
        private Label label1;
        private Label label2;
        private TextBox TXBresul;
        private Label label3;
        private Button BTNcal;
        private Button BTNlimp;
        private Button BTNsalir;
        private GroupBox groupBox1;
    }
}