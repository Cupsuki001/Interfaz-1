﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Arbol : Form
    {
        public Arbol()
        {
            InitializeComponent();
        }

        private void Arbol_Load(object sender, EventArgs e)
        {
            TXBdesc.Enabled = false;
            TXBinteres.Enabled = false;
            TXBtotal.Enabled = false;
        }

        private void BTNcalcular_Click(object sender, EventArgs e)
        {
            double sub, des, tt, imp;
            try
            {
                sub = Convert.ToDouble(MSKsub.Text);
                if (treeView1.Nodes.Equals("Contado"))
                {
                    if (CHKdescuento.Checked == true)
                    {
                        des = sub * 0.05;
                        TXBdesc.Text = des.ToString();
                        tt = sub - des;
                        TXBtotal.Text = tt.ToString();
                    }
                    else
                    {
                        if (CHKdescuento.Checked == false)
                        {
                            TXBdesc.Text = "";
                            imp = sub * 1.15;
                            TXBinteres.Text = imp.ToString();
                        }
                    }
                }
                else
                {
                    if (sub > 101 && sub <= 3000)
                    {
                        if (CHKdescuento.Checked == true)
                        {
                            des = sub * 0.10;
                            TXBdesc.Text = des.ToString();
                            tt = sub - des;
                            TXBtotal.Text = tt.ToString();
                        }
                        else
                        {
                            if (CHKdescuento.Checked == false)
                            {
                                TXBdesc.Text = "";
                                imp = sub * 1.15;
                                TXBinteres.Text = imp.ToString();
                            }
                        }
                    }
                    else 
                    {
                      if (sub <= 3001) 
                      {
                            if (CHKdescuento.Checked == true)
                            {
                                des = sub * 0.12;
                                TXBdesc.Text = des.ToString();
                                tt = sub - des;
                                TXBtotal.Text = tt.ToString();
                            }
                            else
                            {
                                if (CHKdescuento.Checked == false)
                                {
                                    TXBdesc.Text = "";
                                    imp = sub * 1.15;
                                    TXBinteres.Text = imp.ToString();
                                }
                            }
                      }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("No puede estar en blanco");
            }
        }

        private void BTNlimp_Click(object sender, EventArgs e)
        {
            TXBdesc.Clear();
            TXBinteres.Clear();
            TXBtotal.Clear();
            MSKsub.Clear();
            CHKdescuento.Checked = false;
        }

        private void BTNsalir_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
