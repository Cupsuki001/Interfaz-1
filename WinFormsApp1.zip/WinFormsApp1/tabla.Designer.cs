﻿namespace WinFormsApp1
{
    partial class tabla
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            TreeNode treeNode1 = new TreeNode("Efectivo");
            TreeNode treeNode2 = new TreeNode("Credito");
            TreeNode treeNode3 = new TreeNode("Tipos de pago", new TreeNode[] { treeNode1, treeNode2 });
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            TXBadi = new Button();
            BTNborrar = new Button();
            TXBnomb = new TextBox();
            dataGridView1 = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            LBLconta = new Label();
            label4 = new Label();
            label6 = new Label();
            label7 = new Label();
            TXBsubfact = new TextBox();
            TXBfact = new TextBox();
            MSKcodigo = new MaskedTextBox();
            MSKprecio = new MaskedTextBox();
            MSKcant = new MaskedTextBox();
            label8 = new Label();
            TXBimpuesto = new TextBox();
            groupBox1 = new GroupBox();
            button1 = new Button();
            TXBdola = new TextBox();
            TXBcord = new TextBox();
            CMBtipo = new ComboBox();
            BTNpagar = new Button();
            label10 = new Label();
            label9 = new Label();
            treeView1 = new TreeView();
            TXBsub = new TextBox();
            label5 = new Label();
            groupBox2 = new GroupBox();
            TXBdinero = new TextBox();
            label13 = new Label();
            TXBtipopago = new TextBox();
            label12 = new Label();
            label11 = new Label();
            TXBvuelt = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(53, 57);
            label1.Name = "label1";
            label1.Size = new Size(58, 20);
            label1.TabIndex = 0;
            label1.Text = "Codigo";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(53, 147);
            label2.Name = "label2";
            label2.Size = new Size(64, 20);
            label2.TabIndex = 1;
            label2.Text = "Nombre";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(352, 132);
            label3.Name = "label3";
            label3.Size = new Size(50, 20);
            label3.TabIndex = 2;
            label3.Text = "Precio";
            // 
            // TXBadi
            // 
            TXBadi.Location = new Point(611, 53);
            TXBadi.Margin = new Padding(3, 4, 3, 4);
            TXBadi.Name = "TXBadi";
            TXBadi.Size = new Size(86, 31);
            TXBadi.TabIndex = 3;
            TXBadi.Text = "Adicionar";
            TXBadi.UseVisualStyleBackColor = true;
            TXBadi.Click += TXBadi_Click_1;
            // 
            // BTNborrar
            // 
            BTNborrar.Location = new Point(611, 125);
            BTNborrar.Margin = new Padding(3, 4, 3, 4);
            BTNborrar.Name = "BTNborrar";
            BTNborrar.Size = new Size(86, 31);
            BTNborrar.TabIndex = 4;
            BTNborrar.Text = "Borrar";
            BTNborrar.UseVisualStyleBackColor = true;
            BTNborrar.Click += BTNborrar_Click_1;
            // 
            // TXBnomb
            // 
            TXBnomb.Location = new Point(154, 135);
            TXBnomb.Margin = new Padding(3, 4, 3, 4);
            TXBnomb.Name = "TXBnomb";
            TXBnomb.Size = new Size(125, 27);
            TXBnomb.TabIndex = 6;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column5, Column4 });
            dataGridView1.Location = new Point(41, 204);
            dataGridView1.Margin = new Padding(3, 4, 3, 4);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(684, 200);
            dataGridView1.TabIndex = 8;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // Column1
            // 
            Column1.HeaderText = "Cdigo producto";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            Column1.Width = 125;
            // 
            // Column2
            // 
            Column2.HeaderText = "Nombre producto";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            Column2.Width = 125;
            // 
            // Column3
            // 
            Column3.HeaderText = "Precio producto";
            Column3.MinimumWidth = 6;
            Column3.Name = "Column3";
            Column3.Width = 125;
            // 
            // Column5
            // 
            Column5.HeaderText = "Cantidad";
            Column5.MinimumWidth = 6;
            Column5.Name = "Column5";
            Column5.Width = 125;
            // 
            // Column4
            // 
            Column4.HeaderText = "Subtotal producto";
            Column4.MinimumWidth = 6;
            Column4.Name = "Column4";
            Column4.Width = 125;
            // 
            // LBLconta
            // 
            LBLconta.AutoSize = true;
            LBLconta.Location = new Point(725, 180);
            LBLconta.Name = "LBLconta";
            LBLconta.Size = new Size(0, 20);
            LBLconta.TabIndex = 9;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(352, 60);
            label4.Name = "label4";
            label4.Size = new Size(69, 20);
            label4.TabIndex = 10;
            label4.Text = "Cantidad";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(246, 457);
            label6.Name = "label6";
            label6.Size = new Size(119, 20);
            label6.TabIndex = 14;
            label6.Text = "Sub total factura";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(253, 573);
            label7.Name = "label7";
            label7.Size = new Size(92, 20);
            label7.TabIndex = 15;
            label7.Text = "Total factura";
            // 
            // TXBsubfact
            // 
            TXBsubfact.BackColor = Color.Gainsboro;
            TXBsubfact.Location = new Point(246, 496);
            TXBsubfact.Margin = new Padding(3, 4, 3, 4);
            TXBsubfact.Name = "TXBsubfact";
            TXBsubfact.Size = new Size(114, 27);
            TXBsubfact.TabIndex = 16;
            // 
            // TXBfact
            // 
            TXBfact.BackColor = Color.Gainsboro;
            TXBfact.Location = new Point(246, 609);
            TXBfact.Margin = new Padding(3, 4, 3, 4);
            TXBfact.Name = "TXBfact";
            TXBfact.Size = new Size(114, 27);
            TXBfact.TabIndex = 17;
            // 
            // MSKcodigo
            // 
            MSKcodigo.Location = new Point(154, 57);
            MSKcodigo.Mask = "99999";
            MSKcodigo.Name = "MSKcodigo";
            MSKcodigo.Size = new Size(125, 27);
            MSKcodigo.TabIndex = 18;
            MSKcodigo.ValidatingType = typeof(int);
            // 
            // MSKprecio
            // 
            MSKprecio.Location = new Point(454, 129);
            MSKprecio.Mask = "99999";
            MSKprecio.Name = "MSKprecio";
            MSKprecio.Size = new Size(125, 27);
            MSKprecio.TabIndex = 19;
            MSKprecio.ValidatingType = typeof(int);
            // 
            // MSKcant
            // 
            MSKcant.Location = new Point(454, 53);
            MSKcant.Mask = "99999";
            MSKcant.Name = "MSKcant";
            MSKcant.Size = new Size(125, 27);
            MSKcant.TabIndex = 20;
            MSKcant.ValidatingType = typeof(int);
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(62, 573);
            label8.Name = "label8";
            label8.Size = new Size(71, 20);
            label8.TabIndex = 21;
            label8.Text = "Impuesto";
            // 
            // TXBimpuesto
            // 
            TXBimpuesto.BackColor = Color.Gainsboro;
            TXBimpuesto.Location = new Point(36, 609);
            TXBimpuesto.Name = "TXBimpuesto";
            TXBimpuesto.Size = new Size(125, 27);
            TXBimpuesto.TabIndex = 22;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.AppWorkspace;
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(TXBdola);
            groupBox1.Controls.Add(TXBcord);
            groupBox1.Controls.Add(CMBtipo);
            groupBox1.Controls.Add(BTNpagar);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(treeView1);
            groupBox1.Location = new Point(745, 16);
            groupBox1.Margin = new Padding(3, 4, 3, 4);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(3, 4, 3, 4);
            groupBox1.Size = new Size(229, 620);
            groupBox1.TabIndex = 25;
            groupBox1.TabStop = false;
            groupBox1.Text = "Pago";
            // 
            // button1
            // 
            button1.Location = new Point(52, 568);
            button1.Name = "button1";
            button1.Size = new Size(125, 29);
            button1.TabIndex = 35;
            button1.Text = "Limpiar Datos";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // TXBdola
            // 
            TXBdola.BackColor = Color.Silver;
            TXBdola.Location = new Point(52, 480);
            TXBdola.Name = "TXBdola";
            TXBdola.Size = new Size(125, 27);
            TXBdola.TabIndex = 34;
            // 
            // TXBcord
            // 
            TXBcord.BackColor = Color.Silver;
            TXBcord.Location = new Point(52, 361);
            TXBcord.Name = "TXBcord";
            TXBcord.Size = new Size(125, 27);
            TXBcord.TabIndex = 33;
            // 
            // CMBtipo
            // 
            CMBtipo.DropDownStyle = ComboBoxStyle.DropDownList;
            CMBtipo.FormattingEnabled = true;
            CMBtipo.Items.AddRange(new object[] { "Cordoba", "Dolares", "Mixto" });
            CMBtipo.Location = new Point(52, 212);
            CMBtipo.Margin = new Padding(3, 4, 3, 4);
            CMBtipo.Name = "CMBtipo";
            CMBtipo.Size = new Size(138, 28);
            CMBtipo.TabIndex = 28;
            CMBtipo.SelectedIndexChanged += CMBtipo_SelectedIndexChanged;
            // 
            // BTNpagar
            // 
            BTNpagar.Location = new Point(70, 530);
            BTNpagar.Margin = new Padding(3, 4, 3, 4);
            BTNpagar.Name = "BTNpagar";
            BTNpagar.Size = new Size(86, 31);
            BTNpagar.TabIndex = 32;
            BTNpagar.Text = "Pagar";
            BTNpagar.UseVisualStyleBackColor = true;
            BTNpagar.Click += BTNpagar_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(79, 423);
            label10.Name = "label10";
            label10.Size = new Size(60, 20);
            label10.TabIndex = 31;
            label10.Text = "Dolares";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(79, 304);
            label9.Name = "label9";
            label9.Size = new Size(67, 20);
            label9.TabIndex = 30;
            label9.Text = "Cordoba";
            // 
            // treeView1
            // 
            treeView1.Location = new Point(30, 35);
            treeView1.Margin = new Padding(3, 4, 3, 4);
            treeView1.Name = "treeView1";
            treeNode1.Name = "Nodo1";
            treeNode1.Text = "Efectivo";
            treeNode2.Name = "Nodo2";
            treeNode2.Text = "Credito";
            treeNode3.Name = "Nodo0";
            treeNode3.Text = "Tipos de pago";
            treeView1.Nodes.AddRange(new TreeNode[] { treeNode3 });
            treeView1.Size = new Size(181, 149);
            treeView1.TabIndex = 25;
            treeView1.AfterSelect += treeView1_AfterSelect;
            // 
            // TXBsub
            // 
            TXBsub.BackColor = Color.Gainsboro;
            TXBsub.Location = new Point(45, 496);
            TXBsub.Margin = new Padding(3, 4, 3, 4);
            TXBsub.Name = "TXBsub";
            TXBsub.Size = new Size(114, 27);
            TXBsub.TabIndex = 27;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(45, 457);
            label5.Name = "label5";
            label5.Size = new Size(125, 20);
            label5.TabIndex = 26;
            label5.Text = "Sub total product";
            // 
            // groupBox2
            // 
            groupBox2.BackColor = SystemColors.AppWorkspace;
            groupBox2.Controls.Add(TXBdinero);
            groupBox2.Controls.Add(label13);
            groupBox2.Controls.Add(TXBtipopago);
            groupBox2.Controls.Add(label12);
            groupBox2.Controls.Add(label11);
            groupBox2.Controls.Add(TXBvuelt);
            groupBox2.Location = new Point(418, 411);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(307, 225);
            groupBox2.TabIndex = 28;
            groupBox2.TabStop = false;
            groupBox2.Text = "Datos";
            // 
            // TXBdinero
            // 
            TXBdinero.Location = new Point(154, 46);
            TXBdinero.Name = "TXBdinero";
            TXBdinero.Size = new Size(125, 27);
            TXBdinero.TabIndex = 5;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(11, 46);
            label13.Name = "label13";
            label13.Size = new Size(124, 20);
            label13.TabIndex = 4;
            label13.Text = "Dinero ingresado";
            // 
            // TXBtipopago
            // 
            TXBtipopago.Location = new Point(154, 164);
            TXBtipopago.Name = "TXBtipopago";
            TXBtipopago.Size = new Size(125, 27);
            TXBtipopago.TabIndex = 3;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(36, 171);
            label12.Name = "label12";
            label12.Size = new Size(99, 20);
            label12.TabIndex = 2;
            label12.Text = "Tipo de pago";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(50, 109);
            label11.Name = "label11";
            label11.Size = new Size(52, 20);
            label11.TabIndex = 1;
            label11.Text = "Vuelto";
            // 
            // TXBvuelt
            // 
            TXBvuelt.Location = new Point(154, 102);
            TXBvuelt.Name = "TXBvuelt";
            TXBvuelt.Size = new Size(125, 27);
            TXBvuelt.TabIndex = 0;
            // 
            // tabla
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(988, 667);
            Controls.Add(groupBox2);
            Controls.Add(TXBsub);
            Controls.Add(label5);
            Controls.Add(groupBox1);
            Controls.Add(TXBimpuesto);
            Controls.Add(label8);
            Controls.Add(MSKcant);
            Controls.Add(MSKprecio);
            Controls.Add(MSKcodigo);
            Controls.Add(TXBfact);
            Controls.Add(TXBsubfact);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(LBLconta);
            Controls.Add(dataGridView1);
            Controls.Add(TXBnomb);
            Controls.Add(BTNborrar);
            Controls.Add(TXBadi);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "tabla";
            Text = "tabla";
            Load += tabla_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Button TXBadi;
        private Button BTNborrar;
        private TextBox TXBnomb;
        private DataGridView dataGridView1;
        private Label LBLconta;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column4;
        private Label label4;
        private Label label6;
        private Label label7;
        private TextBox TXBsubfact;
        private TextBox TXBfact;
        private MaskedTextBox MSKcodigo;
        private MaskedTextBox MSKprecio;
        private MaskedTextBox MSKcant;
        private Label label8;
        private TextBox TXBimpuesto;
        private GroupBox groupBox1;
        private Button BTNpagar;
        private Label label10;
        private Label label9;
        private TreeView treeView1;
        private TextBox TXBsub;
        private Label label5;
        private ComboBox CMBtipo;
        private GroupBox groupBox2;
        private Label label11;
        private TextBox TXBvuelt;
        private Label label12;
        private TextBox TXBdinero;
        private Label label13;
        private TextBox TXBtipopago;
        private TextBox TXBdola;
        private TextBox TXBcord;
        private Button button1;
    }
}