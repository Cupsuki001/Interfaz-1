﻿namespace WinFormsApp1
{
    partial class Consola2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CMBbien = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.MSKvalor = new System.Windows.Forms.MaskedTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.TXBresul = new System.Windows.Forms.TextBox();
            this.BTNcal = new System.Windows.Forms.Button();
            this.BTNlimp = new System.Windows.Forms.Button();
            this.BTNsalir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // CMBbien
            // 
            this.CMBbien.FormattingEnabled = true;
            this.CMBbien.Items.AddRange(new object[] {
            "Edificio",
            "Vehiculo",
            "Equpo de Compt"});
            this.CMBbien.Location = new System.Drawing.Point(54, 50);
            this.CMBbien.Name = "CMBbien";
            this.CMBbien.Size = new System.Drawing.Size(121, 23);
            this.CMBbien.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(54, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Seleccione un bien";
            // 
            // MSKvalor
            // 
            this.MSKvalor.Location = new System.Drawing.Point(54, 139);
            this.MSKvalor.Mask = "99999";
            this.MSKvalor.Name = "MSKvalor";
            this.MSKvalor.Size = new System.Drawing.Size(100, 23);
            this.MSKvalor.TabIndex = 2;
            this.MSKvalor.ValidatingType = typeof(int);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(54, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Ingrese su valor ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(230, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "Depreciacion";
            // 
            // TXBresul
            // 
            this.TXBresul.Location = new System.Drawing.Point(221, 48);
            this.TXBresul.Name = "TXBresul";
            this.TXBresul.Size = new System.Drawing.Size(145, 23);
            this.TXBresul.TabIndex = 5;
            // 
            // BTNcal
            // 
            this.BTNcal.Location = new System.Drawing.Point(221, 92);
            this.BTNcal.Name = "BTNcal";
            this.BTNcal.Size = new System.Drawing.Size(75, 23);
            this.BTNcal.TabIndex = 6;
            this.BTNcal.Text = "Calcular";
            this.BTNcal.UseVisualStyleBackColor = true;
            this.BTNcal.Click += new System.EventHandler(this.BTNcal_Click);
            // 
            // BTNlimp
            // 
            this.BTNlimp.Location = new System.Drawing.Point(308, 126);
            this.BTNlimp.Name = "BTNlimp";
            this.BTNlimp.Size = new System.Drawing.Size(75, 23);
            this.BTNlimp.TabIndex = 7;
            this.BTNlimp.Text = "Limpiar";
            this.BTNlimp.UseVisualStyleBackColor = true;
            this.BTNlimp.Click += new System.EventHandler(this.BTNlimp_Click);
            // 
            // BTNsalir
            // 
            this.BTNsalir.Location = new System.Drawing.Point(221, 161);
            this.BTNsalir.Name = "BTNsalir";
            this.BTNsalir.Size = new System.Drawing.Size(75, 23);
            this.BTNsalir.TabIndex = 8;
            this.BTNsalir.Text = "Salir";
            this.BTNsalir.UseVisualStyleBackColor = true;
            this.BTNsalir.Click += new System.EventHandler(this.BTNsalir_Click);
            // 
            // Consola2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(403, 198);
            this.Controls.Add(this.BTNsalir);
            this.Controls.Add(this.BTNlimp);
            this.Controls.Add(this.BTNcal);
            this.Controls.Add(this.TXBresul);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.MSKvalor);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CMBbien);
            this.Name = "Consola2";
            this.Text = "Consola2";
            this.Load += new System.EventHandler(this.Consola2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ComboBox CMBbien;
        private Label label1;
        private MaskedTextBox MSKvalor;
        private Label label2;
        private Label label3;
        private TextBox TXBresul;
        private Button BTNcal;
        private Button BTNlimp;
        private Button BTNsalir;
    }
}