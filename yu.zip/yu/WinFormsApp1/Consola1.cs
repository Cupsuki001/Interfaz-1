﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Consola1 : Form
    {
        public Consola1()
        {
            InitializeComponent();
        }

        private void Consola1_Load(object sender, EventArgs e)
        {
            TXBresul.Enabled = false;
        }

        private void BTNcalcular_Click(object sender, EventArgs e)
        {
            double c, tt;
            try
            {
                c = Convert.ToDouble(TXBcel.Text);
                if (RDfaren.Checked == true)
                {
                    tt = (c * 9 / 5) + 32;
                    TXBresul.Text = tt.ToString();
                }
                else 
                {
                    tt = c + 273.15;
                    TXBresul.Text = tt.ToString();
                }
            
            }
            catch (Exception ex) 
            {
                MessageBox.Show("No puede estar en blanco");
            }
        }

        private void BTNlimp_Click(object sender, EventArgs e)
        {
            TXBcel.Text = "";
            TXBresul.Text = "";
        }

        private void BTNsalir_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
