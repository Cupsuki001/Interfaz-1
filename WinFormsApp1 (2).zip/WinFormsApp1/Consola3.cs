﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Consola3 : Form
    {
        public Consola3()
        {
            InitializeComponent();
        }

        private void Consola3_Load(object sender, EventArgs e)
        {
            TXBresul.Enabled = false;
        }

        private void BTNcal_Click(object sender, EventArgs e)
        {
            double ingr, egre, ut;
            try 
            {
              ingr = Convert.ToDouble(MSKingr.Text);
                egre = Convert.ToDouble(MSKegre.Text);

                if(ingr < 7000 || ingr > 500000) 
                {
                    MessageBox.Show("No puede ser menor a 7000 o mayor a 500000");
                    MSKingr.Text = "";
                }
                else 
                {
                      if(egre > ingr || egre == 0) 
                      {
                        MessageBox.Show("No puede ser mayor a los ingresos ni cero");
                        MSKegre.Text = "";
                      }
                    else 
                    {
                        ut = ingr - egre;
                        TXBresul.Text = ut.ToString();
                    }
                }
            }
            catch (Exception ex) 
            {
              MessageBox.Show("No puede estar en blanco");
            }
        }

        private void BTNlimp_Click(object sender, EventArgs e)
        {
            MSKegre.Text = "";
            MSKingr.Text = "";
            TXBresul.Text = "";
        }

        private void BTNsalir_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
