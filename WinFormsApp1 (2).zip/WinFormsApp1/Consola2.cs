﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Consola2 : Form
    {
        public Consola2()
        {
            InitializeComponent();
        }

        private void Consola2_Load(object sender, EventArgs e)
        {
            TXBresul.Enabled = false;
        }

        private void BTNcal_Click(object sender, EventArgs e)
        {
            double dep , tt;
            try 
            {
               dep = Convert.ToDouble(MSKvalor.Text);

               if(dep == 0) 
               {
                    MessageBox.Show("NO PUEDE SER 0");
                    MSKvalor.Text = "";
               }
                else 
                {
                    if (CMBbien.SelectedItem.Equals("Edificio"))
                    {
                        tt = dep / 2;
                        TXBresul.Text = tt.ToString();
                    }
                    if (CMBbien.SelectedItem.Equals("Vehiculo"))
                    {
                        tt = dep / 5;
                        TXBresul.Text = tt.ToString();
                    }
                    else
                    {
                        tt = dep / 2;
                        TXBresul.Text = tt.ToString();
                    }
                }
            }
            catch (Exception ex) 
            {
                MessageBox.Show("No puede estar en blanco");
            }
        }

        private void BTNlimp_Click(object sender, EventArgs e)
        {
            TXBresul.Text = "";
            MSKvalor.Text = "";
            CMBbien.Text = "";
        }

        private void BTNsalir_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
