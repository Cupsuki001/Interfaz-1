﻿namespace WinFormsApp1
{
    partial class Arbol
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("Contado");
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("Credito");
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("Factura", new System.Windows.Forms.TreeNode[] {
            treeNode13,
            treeNode14});
            this.CHKdescuento = new System.Windows.Forms.CheckBox();
            this.BTNsalir = new System.Windows.Forms.Button();
            this.BTNlimp = new System.Windows.Forms.Button();
            this.BTNcalcular = new System.Windows.Forms.Button();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TXBtotal = new System.Windows.Forms.TextBox();
            this.TXBinteres = new System.Windows.Forms.TextBox();
            this.TXBdesc = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.MSKsub = new System.Windows.Forms.MaskedTextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // CHKdescuento
            // 
            this.CHKdescuento.AutoSize = true;
            this.CHKdescuento.Location = new System.Drawing.Point(108, 168);
            this.CHKdescuento.Name = "CHKdescuento";
            this.CHKdescuento.Size = new System.Drawing.Size(82, 19);
            this.CHKdescuento.TabIndex = 19;
            this.CHKdescuento.Text = "Descuento";
            this.CHKdescuento.UseVisualStyleBackColor = true;
            // 
            // BTNsalir
            // 
            this.BTNsalir.Location = new System.Drawing.Point(108, 283);
            this.BTNsalir.Name = "BTNsalir";
            this.BTNsalir.Size = new System.Drawing.Size(75, 23);
            this.BTNsalir.TabIndex = 17;
            this.BTNsalir.Text = "Cancelar";
            this.BTNsalir.UseVisualStyleBackColor = true;
            this.BTNsalir.Click += new System.EventHandler(this.BTNsalir_Click);
            // 
            // BTNlimp
            // 
            this.BTNlimp.Location = new System.Drawing.Point(168, 215);
            this.BTNlimp.Name = "BTNlimp";
            this.BTNlimp.Size = new System.Drawing.Size(75, 23);
            this.BTNlimp.TabIndex = 16;
            this.BTNlimp.Text = "Limpiar";
            this.BTNlimp.UseVisualStyleBackColor = true;
            this.BTNlimp.Click += new System.EventHandler(this.BTNlimp_Click);
            // 
            // BTNcalcular
            // 
            this.BTNcalcular.Location = new System.Drawing.Point(43, 215);
            this.BTNcalcular.Name = "BTNcalcular";
            this.BTNcalcular.Size = new System.Drawing.Size(75, 23);
            this.BTNcalcular.TabIndex = 15;
            this.BTNcalcular.Text = "Calcular";
            this.BTNcalcular.UseVisualStyleBackColor = true;
            this.BTNcalcular.Click += new System.EventHandler(this.BTNcalcular_Click);
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(54, 49);
            this.treeView1.Name = "treeView1";
            treeNode13.Name = "Nodo1";
            treeNode13.Text = "Contado";
            treeNode14.Name = "Nodo2";
            treeNode14.Text = "Credito";
            treeNode15.Name = "Nodo0";
            treeNode15.Text = "Factura";
            this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode15});
            this.treeView1.Size = new System.Drawing.Size(189, 97);
            this.treeView1.TabIndex = 14;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.TXBtotal);
            this.groupBox1.Controls.Add(this.TXBinteres);
            this.groupBox1.Controls.Add(this.TXBdesc);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.MSKsub);
            this.groupBox1.Location = new System.Drawing.Point(275, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(274, 282);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ingrese";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(55, 216);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 15);
            this.label4.TabIndex = 16;
            this.label4.Text = "Total";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(51, 152);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 15);
            this.label3.TabIndex = 15;
            this.label3.Text = "Interes";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(41, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 15);
            this.label2.TabIndex = 14;
            this.label2.Text = "Descuento";
            // 
            // TXBtotal
            // 
            this.TXBtotal.Location = new System.Drawing.Point(152, 208);
            this.TXBtotal.Name = "TXBtotal";
            this.TXBtotal.Size = new System.Drawing.Size(100, 23);
            this.TXBtotal.TabIndex = 13;
            // 
            // TXBinteres
            // 
            this.TXBinteres.Location = new System.Drawing.Point(152, 144);
            this.TXBinteres.Name = "TXBinteres";
            this.TXBinteres.Size = new System.Drawing.Size(100, 23);
            this.TXBinteres.TabIndex = 12;
            // 
            // TXBdesc
            // 
            this.TXBdesc.Location = new System.Drawing.Point(152, 82);
            this.TXBdesc.Name = "TXBdesc";
            this.TXBdesc.Size = new System.Drawing.Size(100, 23);
            this.TXBdesc.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 15);
            this.label1.TabIndex = 10;
            this.label1.Text = "Sub tottal factura";
            // 
            // MSKsub
            // 
            this.MSKsub.Location = new System.Drawing.Point(152, 25);
            this.MSKsub.Mask = "99999";
            this.MSKsub.Name = "MSKsub";
            this.MSKsub.Size = new System.Drawing.Size(100, 23);
            this.MSKsub.TabIndex = 9;
            this.MSKsub.ValidatingType = typeof(int);
            // 
            // Arbol
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(569, 331);
            this.Controls.Add(this.CHKdescuento);
            this.Controls.Add(this.BTNsalir);
            this.Controls.Add(this.BTNlimp);
            this.Controls.Add(this.BTNcalcular);
            this.Controls.Add(this.treeView1);
            this.Controls.Add(this.groupBox1);
            this.Name = "Arbol";
            this.Text = "Arbol";
            this.Load += new System.EventHandler(this.Arbol_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private CheckBox CHKdescuento;
        private Button BTNsalir;
        private Button BTNlimp;
        private Button BTNcalcular;
        private TreeView treeView1;
        private GroupBox groupBox1;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox TXBtotal;
        private TextBox TXBinteres;
        private TextBox TXBdesc;
        private Label label1;
        private MaskedTextBox MSKsub;
    }
}