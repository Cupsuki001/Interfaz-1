﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class tabla : Form
    {
        public tabla()
        {
            InitializeComponent();
        }
        private int num = 0;
        public double ttp = 0;


        private void TXBadi_Click_1(object sender, EventArgs e)
        {
            try
            {
                double pre, cant, tt;

                // Verificar si los campos están vacíos
                if (string.IsNullOrEmpty(MSKcodigo.Text) || string.IsNullOrEmpty(TXBnomb.Text) ||
                    string.IsNullOrEmpty(MSKprecio.Text) || string.IsNullOrEmpty(MSKcant.Text))
                {
                    MessageBox.Show("Por favor, complete todos los campos.");
                    return;
                }

                // Convertir los valores de los campos
                pre = Convert.ToDouble(MSKprecio.Text);
                cant = Convert.ToDouble(MSKcant.Text);

                tt = pre * cant;
                TXBsub.Text = tt.ToString();

                int num = dataGridView1.Rows.Add();
                dataGridView1.Rows[num].Cells[0].Value = MSKcodigo.Text;
                dataGridView1.Rows[num].Cells[1].Value = TXBnomb.Text;
                dataGridView1.Rows[num].Cells[2].Value = MSKprecio.Text;
                dataGridView1.Rows[num].Cells[3].Value = MSKcant.Text;
                dataGridView1.Rows[num].Cells[4].Value = TXBsub.Text;

                // Calcular totales
                double sum = 0, imp = 0;
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    sum += Convert.ToDouble(row.Cells["Column4"].Value);
                    imp = (sum * 1.15) - sum;
                    ttp = imp + sum;
                }

                TXBsubfact.Text = sum.ToString();
                TXBfact.Text = ttp.ToString();
                TXBimpuesto.Text = imp.ToString();

                // Limpiar campos después de agregar la fila
                MSKcodigo.Text = "";
                TXBnomb.Text = "";
                MSKprecio.Text = "";
                MSKcant.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show("No puede estar en blanco");

            }
        }

        private void BTNborrar_Click_1(object sender, EventArgs e)
        {
            if (num != -1)
            {
                dataGridView1.Rows.RemoveAt(num);
            }
           
        }

        private void tabla_Load(object sender, EventArgs e)
        {
            TXBsub.Enabled = false;
            TXBsubfact.Enabled = false;
            TXBsub.Enabled = false;
            TXBfact.Enabled = false;
            TXBimpuesto.Enabled = false;
            TXBcord.Enabled = false;
            TXBdola.Enabled = false;
            CMBtipo.Enabled = false;
            TXBtipopago.Enabled = false;
            TXBvuelt.Enabled = false;
            TXBdinero.Enabled = false;

            if(dataGridView1.Rows.Count == 0) 
            {
              BTNborrar.Enabled = false;
            }
            else 
            {
                BTNborrar.Enabled = true;
            }
          
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            num = e.RowIndex;
            if (num != -1)
            {
                LBLconta.Text = (string)dataGridView1.Rows[num].Cells[1].Value;
            }

            
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {

            if (treeView1.SelectedNode.Text.Equals("Efectivo"))
            {
                CMBtipo.Enabled = true;
            }
            else
            {
                TXBcord.Enabled = false;
                TXBdola.Enabled = false;
                CMBtipo.Enabled = false;
            }
        }

        private void CMBtipo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CMBtipo.SelectedItem.ToString() == "Cordoba")
            {
                TXBdola.Enabled = false;
                TXBcord.Enabled = true;
            }
            else if (CMBtipo.SelectedItem.ToString() == "Dolares")
            {
                TXBcord.Enabled = false;
                TXBdola.Enabled = true;
            }
            else
            {
                TXBcord.Enabled = true;
                TXBdola.Enabled = true;
            }
        }

        private void BTNpagar_Click(object sender, EventArgs e)
        {
            double c, d = 0, tt , con = 0 , mix;
            // Reemplaza ObtenerTotalAPagar con la lógica que corresponda

            if (treeView1.SelectedNode.Text.Equals("Credito"))
            {
                tt = ttp - ttp;
                TXBdinero.Text = ttp.ToString();
                TXBvuelt.Text = "0";
                TXBtipopago.Text = "Credito";
            }
            else
            {
                if (CMBtipo.SelectedItem == null)
                {
                    MessageBox.Show("Seleccione un tipo de pago.");
                    return;
                }
                if (CMBtipo.SelectedItem.ToString() == "Cordoba")
                {
                    TXBdola.Enabled = false;
                    TXBcord.Enabled = true;

                    if (!double.TryParse(TXBcord.Text, out c) || c < ttp)
                    {
                        MessageBox.Show("La cantidad en córdobas no es válida o es menor al total a pagar.");
                        TXBcord.Focus();
                        return;
                    }
                    else
                    {
                        tt = c - ttp;
                        d = 0;
                        TXBdinero.Text = c.ToString();
                        TXBvuelt.Text = tt.ToString();
                        TXBtipopago.Text = "Efectivo";
                    }
                }
                else if (CMBtipo.SelectedItem.ToString() == "Dolares")
                {
                    TXBcord.Enabled = false;
                    TXBdola.Enabled = true;
                    d = Convert.ToDouble(TXBdola.Text);
                    con = d * 36.81; 

                    if (!double.TryParse(TXBdola.Text, out d) || con < ttp)
                    {
                        MessageBox.Show("La cantidad en córdobas no es válida o es menor al total a pagar.");
                        TXBdola.Focus();
                        return;
                    }
                    else
                    {
                        tt = con - ttp;
                        TXBdinero.Text = d.ToString();
                        TXBvuelt.Text = tt.ToString();
                        TXBtipopago.Text = "Efectivo";
                    }
                }
                else
                {
                    c = Convert.ToDouble(TXBcord.Text);
                    d = Convert.ToDouble(TXBdola.Text);
                    TXBcord.Enabled = true;
                    TXBdola.Enabled = true;
                    con = d * 36.81;
                    mix = con + c;

                    if (!double.TryParse(TXBdola.Text, out d) && !double.TryParse(TXBcord.Text, out c) && mix < ttp)
                    {
                        MessageBox.Show("La cantidad en córdobas no es válida o es menor al total a pagar.");
                    }
                    else
                    {
                        tt = mix - ttp;
                        TXBdinero.Text = mix.ToString();
                        TXBvuelt.Text = tt.ToString();
                        TXBtipopago.Text = "Efectivo";
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MSKcant.Text = "";
            MSKcodigo.Text = "";
            MSKprecio.Text = "";
            TXBnomb.Text = "";
            TXBimpuesto.Text = "";
            TXBdola.Text = "";
            TXBcord.Text = "";
            TXBfact.Text = "";
            TXBsub.Text = "";
            TXBsubfact.Text = "";
            TXBtipopago.Text = "";
            TXBvuelt.Text = "";
            TXBdinero.Text = "";
            CMBtipo.Text = "";
            dataGridView1.Rows.Clear();
        }

        



    }
}
