﻿namespace WinFormsApp1
{
    partial class Consola1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.RDfaren = new System.Windows.Forms.RadioButton();
            this.RDkelv = new System.Windows.Forms.RadioButton();
            this.BTNcalcular = new System.Windows.Forms.Button();
            this.BTNsalir = new System.Windows.Forms.Button();
            this.BTNlimp = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.TXBresul = new System.Windows.Forms.TextBox();
            this.TXBcel = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(244, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Celsius";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.groupBox1.Controls.Add(this.RDfaren);
            this.groupBox1.Controls.Add(this.RDkelv);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox1.Location = new System.Drawing.Point(12, 21);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 129);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Opciones";
            // 
            // RDfaren
            // 
            this.RDfaren.AutoSize = true;
            this.RDfaren.Location = new System.Drawing.Point(20, 84);
            this.RDfaren.Name = "RDfaren";
            this.RDfaren.Size = new System.Drawing.Size(84, 19);
            this.RDfaren.TabIndex = 4;
            this.RDfaren.TabStop = true;
            this.RDfaren.Text = " Fahrenheit";
            this.RDfaren.UseVisualStyleBackColor = true;
            // 
            // RDkelv
            // 
            this.RDkelv.AutoSize = true;
            this.RDkelv.Location = new System.Drawing.Point(20, 39);
            this.RDkelv.Name = "RDkelv";
            this.RDkelv.Size = new System.Drawing.Size(57, 19);
            this.RDkelv.TabIndex = 3;
            this.RDkelv.TabStop = true;
            this.RDkelv.Text = "Kelvin";
            this.RDkelv.UseVisualStyleBackColor = true;
            // 
            // BTNcalcular
            // 
            this.BTNcalcular.Location = new System.Drawing.Point(14, 198);
            this.BTNcalcular.Name = "BTNcalcular";
            this.BTNcalcular.Size = new System.Drawing.Size(75, 23);
            this.BTNcalcular.TabIndex = 3;
            this.BTNcalcular.Text = "Calcular";
            this.BTNcalcular.UseVisualStyleBackColor = true;
            this.BTNcalcular.Click += new System.EventHandler(this.BTNcalcular_Click);
            // 
            // BTNsalir
            // 
            this.BTNsalir.Location = new System.Drawing.Point(343, 198);
            this.BTNsalir.Name = "BTNsalir";
            this.BTNsalir.Size = new System.Drawing.Size(75, 23);
            this.BTNsalir.TabIndex = 4;
            this.BTNsalir.Text = "Salir";
            this.BTNsalir.UseVisualStyleBackColor = true;
            this.BTNsalir.Click += new System.EventHandler(this.BTNsalir_Click);
            // 
            // BTNlimp
            // 
            this.BTNlimp.Location = new System.Drawing.Point(137, 198);
            this.BTNlimp.Name = "BTNlimp";
            this.BTNlimp.Size = new System.Drawing.Size(75, 23);
            this.BTNlimp.TabIndex = 5;
            this.BTNlimp.Text = "Limpiar";
            this.BTNlimp.UseVisualStyleBackColor = true;
            this.BTNlimp.Click += new System.EventHandler(this.BTNlimp_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(244, 135);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 15);
            this.label2.TabIndex = 6;
            this.label2.Text = "Resultado";
            // 
            // TXBresul
            // 
            this.TXBresul.Location = new System.Drawing.Point(331, 127);
            this.TXBresul.Name = "TXBresul";
            this.TXBresul.Size = new System.Drawing.Size(100, 23);
            this.TXBresul.TabIndex = 7;
            // 
            // TXBcel
            // 
            this.TXBcel.Location = new System.Drawing.Point(331, 51);
            this.TXBcel.Name = "TXBcel";
            this.TXBcel.Size = new System.Drawing.Size(100, 23);
            this.TXBcel.TabIndex = 8;
            // 
            // Consola1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(469, 255);
            this.Controls.Add(this.TXBcel);
            this.Controls.Add(this.TXBresul);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BTNlimp);
            this.Controls.Add(this.BTNsalir);
            this.Controls.Add(this.BTNcalcular);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "Consola1";
            this.Text = "Consola1";
            this.Load += new System.EventHandler(this.Consola1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Label label1;
        private GroupBox groupBox1;
        private RadioButton RDfaren;
        private RadioButton RDkelv;
        private Button BTNcalcular;
        private Button BTNsalir;
        private Button BTNlimp;
        private Label label2;
        private TextBox TXBresul;
        private TextBox TXBcel;
    }
}