﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class tabla : Form
    {
        public tabla()
        {
            InitializeComponent();
        }
        private int num = 0;
        private void TXBadi_Click(object sender, EventArgs e)
        {
            try 
            {
                int num = dataGridView1.Rows.Add();
                double tt, pre, cant , imp=0 , ttp=0 ,sum =0;

                pre = Convert.ToDouble(MSKprecio.Text);
                cant = Convert.ToDouble(MSKcant.Text);
              
                tt = pre * cant;
                TXBsub.Text = tt.ToString();

                dataGridView1.Rows[num].Cells[0].Value = MSKcodigo.Text;
                dataGridView1.Rows[num].Cells[1].Value = TXBnomb.Text;
                dataGridView1.Rows[num].Cells[2].Value = MSKprecio.Text;
                dataGridView1.Rows[num].Cells[3].Value = MSKcant.Text;
                dataGridView1.Rows[num].Cells[4].Value = TXBsub.Text;

                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    sum += Convert.ToDouble(row.Cells["Column4"].Value);
                    imp = (sum * 1.15) - sum;
                    ttp = imp + sum;
                }

                TXBsubfact.Text = sum.ToString();
                TXBfact.Text = ttp.ToString();
                TXBimpuesto.Text = imp.ToString();

                MSKcodigo.Text = "";
                TXBnomb.Text = "";
                MSKprecio.Text = "";
                MSKcant.Text = "";

            }
            catch (Exception ex) 
            {
                MessageBox.Show("No puede estar en blanco");
                if (num != -1)
                {
                    dataGridView1.Rows.RemoveAt(num);
                }
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            num = e.RowIndex;
            if(num != -1) 
            {
              LBLconta.Text = (string)dataGridView1.Rows[num].Cells[1].Value;
            }
        }

        private void BTNborrar_Click(object sender, EventArgs e)
        {
            if (num != -1)
            {
                dataGridView1.Rows.RemoveAt(num);
            }
        }

        private void tabla_Load(object sender, EventArgs e)
        {
            TXBsub.Enabled = false;
            TXBsubfact.Enabled = false;
            TXBsub.Enabled = false;
            TXBfact.Enabled = false;
            TXBimpuesto.Enabled = false;
        }
    }
}
